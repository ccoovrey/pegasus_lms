#Inital Files
New-Item �C:\users\vagrant\pictures\wallpaper" �type directory
New-Item �C:\users\default\pictures\wallpaper" �type directory
cp "C:\Users\vagrant\test\*.bmp" C:\Users\vagrant\Pictures\wallpaper
cp "C:\Users\vagrant\test\*.bmp" C:\Users\default\Pictures\wallpaper
cp "C:\Users\vagrant\test\Set-Wallpaper.ps1" C:\windows
cp "C:\Users\vagrant\test\wallpaper.bat" C:\windows
& c:\windows\Set-Wallpaper.ps1 MyPics cp_loading.bmp

# Readme
Move-Item -Path "C:\Users\vagrant\test\Read Me.docx" -Destination "C:\Users\vagrant\Desktop"
Move-Item -Path "C:\Users\vagrant\test\Answers.docx" -Destination "C:\Users\Public\Downloads"

# add users
Write-Host "Add Users"
New-LocalGroup -Name "NCC1701_Crew" -Description "Crew of USS Enterprise"
New-LocalGroup -Name "SFC" -Description "Members of Starfleet Command"
New-LocalGroup -Name "NCC1701_Officers" -Description "Officers of USS Enterprise"
New-LocalGroup -Name "NCC1701_Enlisted" -Description "Enlisted of USS Enterprise"
New-LocalGroup -Name "jkirk" -Description "James Tiberius Kirk"
New-LocalUser -Name "spock" -FullName "Spock" -NoPassword
New-LocalUser -Name "jtkirk" -FullName "James Tiberius Kirk" -NoPassword
New-LocalUser -Name "lmccoy" -FullName "Leonard McCoy" -NoPassword
New-LocalUser -Name "mscott" -FullName "Montgomery Scott" -NoPassword
New-LocalUser -Name "cchaple" -FullName "Christine Chapel" -NoPassword
New-LocalUser -Name "cpike" -FullName "Christopher Pike" -NoPassword
Add-LocalGroupMember -Group "Administrators" -Member "NCC1701_Officers"
Add-LocalGroupMember -Group "Administrators" -Member "jkirk"
Add-LocalGroupMember -Group "Administrators" -Member "spock"
Add-LocalGroupMember -Group "Power Users" -Member "NCC1701_Enlisted"
Add-LocalGroupMember -Group "NCC1701_Officers" -Member "jtkirk"
Add-LocalGroupMember -Group "NCC1701_Officers" -Member "spock"
Add-LocalGroupMember -Group "NCC1701_Officers" -Member "mscott"
Add-LocalGroupMember -Group "NCC1701_Officers" -Member "lmccoy"
Add-LocalGroupMember -Group "NCC1701_Enlisted" -Member "cchaple"
Add-LocalGroupMember -Group "jkirk" -Member "jtkirk"
Add-LocalGroupMember -Group "jkirk" -Member "spock"
Add-LocalGroupMember -Group "jkirk" -Member "mscott"
Add-LocalGroupMember -Group "jkirk" -Member "lmccoy"
Add-LocalGroupMember -Group "jkirk" -Member "cchaple"
Add-LocalGroupMember -Group "SFC" -Member "jtkirk"
Add-LocalGroupMember -Group "SFC" -Member "spock"
Add-LocalGroupMember -Group "SFC" -Member "mscott"
Add-LocalGroupMember -Group "SFC" -Member "cchaple"
Add-LocalGroupMember -Group "SFC" -Member "lmccoy"
Add-LocalGroupMember -Group "SFC" -Member "cpike"
Add-LocalGroupMember -Group "NCC1701_Crew" -Member "jtkirk"
Add-LocalGroupMember -Group "NCC1701_Crew" -Member "spock"
Add-LocalGroupMember -Group "NCC1701_Crew" -Member "mscott"
Add-LocalGroupMember -Group "NCC1701_Crew" -Member "cchaple"
Add-LocalGroupMember -Group "NCC1701_Crew" -Member "lmccoy"

# IIS
Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServerRole -NoRestart
Enable-WindowsOptionalFeature -Online -FeatureName IIS-WebServer -NoRestart
Enable-WindowsOptionalFeature -Online -FeatureName IIS-CommonHttpFeatures -NoRestart
Enable-WindowsOptionalFeature -Online -FeatureName IIS-HttpErrors -NoRestart
Enable-WindowsOptionalFeature -Online -FeatureName IIS-HttpRedirect -NoRestart
Enable-WindowsOptionalFeature -Online -FeatureName IIS-ApplicationDevelopment -NoRestart
cp C:\Users\vagrant\test\index.html C:\inetpub\wwwroot\index.html
cp C:\Users\vagrant\test\*.url C:\Users\vagrant\Desktop

# Other Features
Enable-WindowsOptionalFeature -Online -FeatureName TFTP -NoRestart
Enable-WindowsOptionalFeature -Online -FeatureName TelnetClient -NoRestart
Enable-WindowsOptionalFeature -Online -FeatureName IIS-FTPServer -NoRestart

# RDP
Set-ItemProperty -Path 'HKLM:\System\CurrentControlSet\Control\Terminal Server' -name "fDenyTSConnections" -value 0
Enable-NetFirewallRule -DisplayGroup "Remote Desktop"
net start TermService

# Windows Update
sc.exe config wuauserv start=disabled
sc.exe stop wuauserv

#Firewall
Set-NetFirewallProfile -Profile Domain,Public,Private -Enabled False

# Password Policy
# net accounts /minpwlen:2
# net accounts /maxpwage:356
# net accounts /minpwage:0
# net accounts /uniquepw:2

#secedit /export /cfg c:\secpol.cfg
#(gc C:\secpol.cfg).replace("PasswordComplexity = 1", "PasswordComplexity = 0") | Out-File C:\secpol.cfg
secedit /configure /db c:\windows\security\local.sdb /cfg C:\Users\vagrant\test\secpol.cfg /areas SECURITYPOLICY
rm -force c:\secpol.cfg -confirm:$false

# malware files
Invoke-WebRequest 'https://the.earth.li/~sgtatham/putty/latest/w64/putty-64bit-0.74-installer.msi' -OutFile 'C:\Users\vagrant\test\putty-64bit-0.74-installer.msi'
Start-Process msiexec.exe -ArgumentList '/I C:\Users\vagrant\test\putty-64bit-0.74-installer.msi /quiet'

Invoke-WebRequest 'https://www.realvnc.com/download/file/vnc.files/VNC-Server-6.7.2-Windows-msi.zip' -OutFile 'C:\Users\vagrant\test\VNC-Server-6.7.2-Windows-msi.zip'
Expand-Archive -LiteralPath 'C:\Users\vagrant\test\VNC-Server-6.7.2-Windows-msi.zip' -DestinationPath C:\Users\vagrant\test\
#Start-Process msiexec.exe -ArgumentList '/I C:\Users\vagrant\test\VNC-Server-6.7.2-Windows-en-64bit.msi /quiet'

# files
#cp "C:\Users\vagrant\test\Klingon Tribble Destroyer.bat" C:\Users\vagrant\Documents
Move-Item -Path "C:\Users\vagrant\test\Klingon Tribble Destroyer.bat" C:\Users\vagrant\Documents

#cp "C:\Users\vagrant\test\Romulan Boot Virus.com" C:\windows
Move-Item -Path "C:\Users\vagrant\test\Romulan Boot Virus.com" -Destination C:\windows
attrib +h "C:\windows\Romulan Boot Virus.com"

Write-Host "share"
#Share
New-Item �C:\users\public\open" �type directory
New-SmbShare -Name "FolderShare" -Path "C:\users\public\open" -FullAccess "Everyone"

#Install Scoring Engine
Start-Process msiexec.exe -wait -ArgumentList '/I C:\Users\vagrant\test\CyberPatriot.Practice.Scoring.Report.64-bit.msi /quiet'
cp "C:\Users\vagrant\test\Configuration.dat" "c:\CyberPatriot Scoring Report"

Write-Host "cleaning up"
# Cleanup
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" -Name "wallpaper" -Value �C:\windows\wallpaper.bat�  -PropertyType "String"
& c:\windows\Set-Wallpaper.ps1 MyPics cp1.bmp
del C:\Users\vagrant\test\*.*
del "C:\Users\Public\Desktop\Configuration Tool*.*"
del "C:\Users\Public\Desktop\translation*.*"
#Clear-RecycleBin
Remove-Item -Path "C:\Users\vagrant\test" -Force -Recurse