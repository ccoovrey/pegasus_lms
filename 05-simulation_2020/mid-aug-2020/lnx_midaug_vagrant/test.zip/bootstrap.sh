#!/usr/bin/env bash

sudo chown -R vagrant /home/vagrant
sudo chgrp -R vagrant /home/vagrant

# add users 
sudo groupadd -g 2002 yoda
sudo groupadd -g 2003 -r groupdrive
sudo groupadd -g 2004 -r deathstar
sudo adduser r2d2 --gid 0
echo 'r2d2:password' | sudo chpasswd
sudo adduser d2r2 --gid 0
sudo adduser c3po --gid 2002
sudo adduser darthvader --gid 0
sudo adduser chewbacca --gid 2004

# malware files
## hidden directories
cd /home/vagrant
mkdir .hack
mkdir .malware
## hidden files
cp /home/vagrant/test/i_want_to_hack_computer.mxd /home/vagrant/.hack/i_want_to_hack_computer.mxd
cp /home/vagrant/test/malware_2000.help /home/vagrant/.malware/malware_2000.help
## regular files
cp /home/vagrant/test/evil_hacking_device.mxpp /home/vagrant/code/evil_hacking_device.mxpp
cp /home/vagrant/test/where_are_you_pegasus.hack /home/vagrant/where_are_you_pegasus.hack

echo "DONE!"
