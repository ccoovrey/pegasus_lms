# add users
New-LocalGroup -Name "yoda" 
New-LocalGroup -Name "groupdrive" 
New-LocalGroup -Name "deathstar" 
New-LocalUser -Name "r2d2" -NoPassword
New-LocalUser -Name "d2r2" -NoPassword
New-LocalUser -Name "c3po" -NoPassword
New-LocalUser -Name "darthvader" -NoPassword
New-LocalUser -Name "chewbacca" -NoPassword
Add-LocalGroupMember -Group "Administrators" -Member "r2d2"
Add-LocalGroupMember -Group "Administrators" -Member "d2r2"
Add-LocalGroupMember -Group "groupdrive" -Member "c3po"
Add-LocalGroupMember -Group "Administrators" -Member "darthvader"
Add-LocalGroupMember -Group "deathstar" -Member "chewbacca"

# malware files
# hidden files
cp C:\Users\vagrant\test\i_want_to_hack_computer.mxd C:\Users\vagrant\i_want_to_hack_computer.mxd
attrib +h C:\Users\vagrant\i_want_to_hack_computer.mxd
cp C:\Users\vagrant\test\malware_2000.help C:\Users\vagrant\malware_2000.help
attrib +h C:\Users\vagrant\malware_2000.help
# regular files
cp C:\Users\vagrant\test\evil_hacking_device.mxpp C:\Users\vagrant\Documents\evil_hacking_device.mxpp
cp C:\Users\vagrant\test\where_are_you_pegasus.hack C:\Users\vagrant\where_are_you_pegasus.hack

Remove-Item –path C:\Users\vagrant\testr –recurse

Write-Host "Finished updating"
