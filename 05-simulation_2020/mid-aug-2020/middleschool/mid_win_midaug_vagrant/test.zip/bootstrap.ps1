# add users
New-LocalGroup -Name "odin" 
New-LocalGroup -Name "valhalla" 
New-LocalGroup -Name "earth" 
New-LocalUser -Name "odin" -NoPassword
New-LocalUser -Name "thor" -NoPassword
New-LocalUser -Name "loki" -NoPassword
New-LocalUser -Name "phoneuser" -NoPassword
Add-LocalGroupMember -Group "Administrators" -Member "odin"
Add-LocalGroupMember -Group "valhalla" -Member "thor"
Add-LocalGroupMember -Group "odin" -Member "odin"
Add-LocalGroupMember -Group "phoneuser" -Member "odin"
Add-LocalGroupMember -Group "earth" -Member "loki"

# malware files
# hidden files
cp C:\Users\vagrant\test\thors_hammer.mad C:\Users\vagrant\Documents\thors_hammer.mad
attrib +h C:\Users\vagrant\Documents\thors_hammer.mad

cp C:\Users\vagrant\test\help_doc.help C:\Users\vagrant\help_doc.help
attrib +h C:\Users\vagrant\help_doc.help

cp C:\Users\vagrant\test\a234.admin56 C:\Users\vagrant\a234.admin56
attrib +h C:\Users\vagrant\a234.admin56

# regular files
cp C:\Users\vagrant\test\loki_is_here.hack C:\Users\vagrant\loki_is_here.hack

cd "C:\Users\vagrant"
remove-item test -Recurse -Force

Write-Host "Finished updating"
