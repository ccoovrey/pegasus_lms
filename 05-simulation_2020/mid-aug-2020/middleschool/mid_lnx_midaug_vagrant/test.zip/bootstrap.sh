#!/usr/bin/env bash

sudo chown -R vagrant /home/vagrant
sudo chgrp -R vagrant /home/vagrant

# add users 
sudo groupadd -g 2002 valhalla
sudo groupadd -g 2003 -r odin 
sudo groupadd -g 2004 -r earth 
sudo adduser odin --gid 0
echo 'odin:password' | sudo chpasswd
sudo adduser odin --gid 0,2003
sudo adduser thor --gid 2002
sudo adduser phoneuser --gid 2003
sudo adduser loki --gid 2004

# malware files
## hidden directories
cd /home/vagrant
mkdir .123admin
mkdir .help
mkdir .a
## hidden files
cp /home/vagrant/test/thors_hammer.mad /home/vagrant/.123admin/thors_hammer.mad
cp /home/vagrant/test/help_doc.help /home/vagrant/.help/help_doc.help
cp /home/vagrant/test/a234.admin56 /home/vagrant/.a/a234.admin56
## regular files
cp /home/vagrant/test/loki_is_here.hack /home/vagrant/loki_is_here.hack

echo "DONE!"
